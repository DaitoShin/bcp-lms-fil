    <!DOCTYPE html>
    <html>
    <head>
    <title>FILDIS</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    </head>

    <body>
    <header>
        <div class="logo">
        <img src="iconicon.png" alt="Berger Hut Logo">
        </div>
        <nav>
        <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#Subjects">Subjects</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="#admin">Admin</a></li>
        </ul>
        </nav>
    </header>

    <section id="home" class="hero">
        <div class="hero-content">
        <h1>Welcome to our website</h1>
        <p>To check the Lesson Propers click the button below!</p>
        <a href="#" onclick="goToMainPage()" class="btn">Check Lessons</a>
        </div>
    </section>

    <section id="about" class="about dark-theme">
        <div class="about-content">
        <h2>About Our Website</h2>
        <p>Welcome to our website! This project was created by the students of BSIT 12027 as part of our coursework for lesson purposes. Our team worked collaboratively to develop this platform, showcasing our skills and knowledge in web development. This website features various sections, including a hero image, menu, reservations, testimonials, gallery, and contact form, all designed to provide a user-friendly experience.</p>
        <p>Through this project, we aim to demonstrate our proficiency in HTML, CSS, JavaScript, and the principles of web design, while also ensuring smooth navigation and functionality. Thank you for visiting, and we hope you enjoy exploring our project!</p>
        <a href="#menu" class="btn">Explore Our Menu</a>
        </div>
        <div class="about-image">
        <img src="about.jpg" alt="About Image">
        <img src="about1.jpg" alt="About1 Image">
        </div>
    </section>

    <section id="Subjects" class="Subjects">
        <h2>Featured Subjects</h2>
        <div class="menu-items">
        <div class="menu-item">
            <img src="Soslit.png" alt="Burger 1">
            
            <h3>Sosyedad at Literatura (SOSLIT)</h3>
            <p>Ito ay isang asignatura na tumatalakay sa mga akdang pampanitikan na may kinalaman sa mga isyung panlipunan. Dito, tinatalakay ang mga epekto ng literatura sa kultura, lipunan, at kasaysayan. Tinutulungan nito ang mga estudyante na mas maintindihan ang mga akdang isinulat na may layuning magbigay ng mensahe o magkomento tungkol sa mga kaganapan sa lipunan.

            </p>
        </div>
        <div class="menu-item">
            <img src="komfil.png" alt="Burger 2">
            <h3>Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino (KOMFIL)</h3>
            <p>Ang KOMFIL ay isang kurso na naglalayong palalimin ang kasanayan sa pagpapahayag at pagsasaliksik gamit ang wikang Filipino. Kasama sa kurso ang pag-aaral ng iba’t ibang anyo ng komunikasyon, mula sa pagsulat ng mga akademikong papel hanggang sa pagpapahayag sa iba't ibang media. Tinututukan din ang pag-unawa sa wika at kultura ng mga Pilipino, pati na rin ang papel ng komunikasyon sa ating lipunan.</p>
        </div>
        <div class="menu-item">
            <img src="fildis.png" alt="Burger 3">
            <h3>Filipino sa Iba't Ibang Disiplina (FILDIS)</h3>
            <p>Ang FILDIS ay isang kurso na nakatuon sa paggamit ng wikang Filipino sa iba't ibang disiplina o larangan. Pinapalawak nito ang kaalaman ng mga mag-aaral sa pagsasalin ng mga teknikal at makabagong konsepto mula sa ibang mga disiplina gamit ang Filipino, tulad ng agham, teknolohiya, at iba pang mga larangan na nangangailangan ng mas mataas na antas ng kaalaman sa wika. Ang layunin nito ay mapalakas ang kakayahan ng mga mag-aaral na gamitin ang Filipino sa mga intelektwal at teknikal na usapin.</p>
        </div>
        </div>
    </section>


    <section id="contact" class="contact">
        <div class="contact-container">
        <h2>Contact Us</h2>
        <div class="contact-info">
            <div class="info-item">
            <i class="fas fa-map-marker-alt"></i>
            <p>123 Main Street, City, Country</p>
            </div>
            <div class="info-item">
            <i class="fas fa-phone-alt"></i>
            <p>+1 234 567 890</p>
            </div>
            <div class="info-item">
            <i class="fas fa-envelope"></i>
            <p>bestlinkcollege@gmail.com</p>
            </div>
        </div>
        <form class="contact-form">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" rows="5" required></textarea>
            <button type="submit">Send Message</button>
        </form>
        </div>
    </section>

    <section id="admin" class="admin">
        <div class="admin-content">
        <div>
            <p>Ang Admin section ay isang eksklusibong bahagi ng website na tanging mga awtorisado lamang ang maaaring maka-access...</p>
        </div>
        </div>
    </section>

    <footer class="footer">
        <div class="footer-content">
        <div class="footer-logo">
            <img src="iconicon.png" alt="Logo">
        </div>
        <nav class="footer-links">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#Subjects">Menu</a>
            <a href="#Contact">Contact</a>
        </nav>
        <div class="footer-social">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
        </div>
        <p class="footer-text">&copy; 2025 Bestlink College of the Philippines.</p>
        <p class="footer-text1">All rights reserved.</p>
    </footer>

    <script>
        const sections = document.querySelectorAll("section");
        let currentIndex = 0;
        let isScrolling = false;

        window.addEventListener("wheel", (event) => {
        if (isScrolling) return;
        isScrolling = true;

        if (event.deltaY > 0) {
            currentIndex = Math.min(currentIndex + 1, sections.length - 1);
        } else {
            currentIndex = Math.max(currentIndex - 1, 0);
        }

        sections[currentIndex].scrollIntoView({ behavior: "smooth" });

        setTimeout(() => {
            isScrolling = false;
        }, 1000);
        });
    </script>

    <script>
        function goToMainPage() {
        window.location.href = "mainpage.html";
        }
    </script>
    </body>
    </html>
