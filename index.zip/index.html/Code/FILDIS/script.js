document.addEventListener("DOMContentLoaded", () => {
  const pages = document.querySelectorAll('.page');
  let currentPage = 0;

  function updatePages() {
    pages.forEach((page, index) => {
      page.style.transform = `translateY(${(index - currentPage) * 100}%)`;
      // Add glide effect when the section becomes visible
      if (index === currentPage) {
        page.classList.add('visible');
      } else {
        page.classList.remove('visible');
      }
    });
  }

  // Initialize first positions
  updatePages();

  // Scroll with wheel
  window.addEventListener('wheel', (e) => {
    if (e.deltaY > 0 && currentPage < pages.length - 1) {
      currentPage++;
      updatePages();
    } else if (e.deltaY < 0 && currentPage > 0) {
      currentPage--;
      updatePages();
    }
  });

  // Nav link support
  document.querySelectorAll('nav a').forEach((link, index) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      currentPage = index;
      updatePages();
    });
  });
});
